# GALAXY GBA

Biblioteca web de jogos Game Boy Advance com visual roxo/preto cyberpunk. Ao clicar em um jogo cadastrado, o EmulatorJS abre automaticamente o emulador em uma tela dedicada.

## Publicar no GitHub Pages

1. Extraia o ZIP.
2. Crie um repositório **público** no GitHub.
3. Envie `index.html` e as pastas `jogos/` e `capas/` para a raiz do repositório.
4. No repositório, entre em **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Escolha a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
7. Aguarde a publicação e abra o endereço informado pelo GitHub Pages.

## Adicionar um jogo à biblioteca

1. Coloque o arquivo de jogo autorizado dentro da pasta `jogos/`. Exemplo: `jogos/meu-homebrew.gba`.
2. (Opcional) Coloque uma imagem de capa em `capas/`. Exemplo: `capas/meu-homebrew.png`.
3. Abra `index.html` e procure por `const GAMES = [`.
4. Dentro dos colchetes, adicione um item como este:

```js
{
  title: 'Meu jogo homebrew',
  description: 'Uma aventura feita por mim.',
  file: 'jogos/meu-homebrew.gba',
  cover: 'capas/meu-homebrew.png'
},
```

5. Salve e envie as alterações ao GitHub. Depois que o Pages atualizar, o jogo aparecerá na biblioteca.

Se não tiver capa, remova a linha `cover` ou deixe sem ela. Para vários jogos, separe os objetos por vírgula.

## Abrir uma ROM sem publicar

O botão **Abrir ROM do dispositivo** permite selecionar um arquivo `.gba`, `.zip` ou `.bin` no próprio aparelho. Esse arquivo não é enviado ao GitHub.

## Observações importantes

- O emulador é carregado pelo CDN do EmulatorJS; é necessária conexão com a internet.
- GitHub Pages é hospedagem estática e tem limites de tamanho/uso. Não é ideal para uma coleção grande de ROMs.
- O repositório é público neste fluxo. Não envie ROMs comerciais protegidas por direitos autorais sem autorização. Use jogos homebrew, próprios, de domínio público ou com licença que permita redistribuição.
- O botão de tela cheia depende do suporte do navegador.
- O arquivo `jogos/LEIA-ME.txt` é apenas um lembrete; adicione suas próprias ROMs autorizadas.
